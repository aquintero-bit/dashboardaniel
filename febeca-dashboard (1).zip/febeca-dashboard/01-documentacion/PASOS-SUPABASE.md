# Febeca · Siguientes pasos con Supabase ya creado

Tres cosas, en orden. En cada una puede salir algo: si aparece un error, copiar el mensaje exacto.

## 1. Aplicar el esquema

SQL Editor → New query → pegar `febeca-supabase-consolidado.sql` completo → **Run**.

Está probado contra PostgreSQL 16 puro. El `auth` de Supabase puede tener alguna diferencia
menor; si sale un error, anotar el mensaje literal y la línea.

## 2. Exponer el esquema `app`

Settings → API → **Exposed schemas** → agregar `app` junto a `public` → Save.

Verificar en el SQL Editor:

```sql
select count(*) from app.indicadores;   -- debe dar 14
select * from app.v_origenes_sin_jefe;  -- debe dar 2 filas: nacional e internacional
```

## 3. Correr la semilla

Antes, editar en `03-semilla/seed.mjs`:

- `USUARIOS` → correos, nombres y roles reales
- `CLASIFICACION` → qué marcas son nacionales y cuáles internacionales

Luego:

```bash
cd 03-semilla
npm install
SUPABASE_URL=https://TU-PROYECTO.supabase.co \
SUPABASE_SERVICE_ROLE=eyJ... \
node seed.mjs [ruta/al/export-marcas-del-SIM.xlsx]
```

La **service role key** está en Settings → API, marcada como secreta.

> Esa clave no va al frontend, no va a ningún repositorio y no se comparte con nadie.
> Solo la usa `seed.mjs` desde tu máquina.

El argumento del xlsx es opcional: es la exportación del SIM con `Parameter = Marca`, sin
filtro, 12 meses, `Venta Neta`. Sin él, solo registra las marcas de `CLASIFICACION`.

## 4. Abrir el módulo de administración

Abrir `04-frontend/febeca-admin.jsx`. Pide:

- **Project URL** (Settings → API)
- **anon public key** (Settings → API; esta sí es pública)

Entrar con el correo y contraseña del admin definido en la semilla.

## Verificación final

```sql
select codigo, origen, estado, responsables from app.v_marcas order by codigo;
select * from app.v_jefaturas;
select * from app.v_origenes_sin_jefe;   -- ahora debe estar vacío
select * from app.v_actividad order by cuando desc limit 20;
```

## Errores frecuentes

| Síntoma | Causa | Arreglo |
|---|---|---|
| Todo devuelve 404 | `app` no está en Exposed schemas | Paso 2 |
| `permission denied for schema app` | Faltan los grants | Están al final del consolidado; reaplicar ese bloque |
| `Tu perfil no existe todavía` al entrar | El trigger sobre `auth.users` no se creó | Reaplicar la sección 1 de la migración 006 desde el SQL Editor |
| La semilla falla en `perfiles` | El usuario existe en Auth pero no tiene perfil | Mismo caso anterior |
| `No tienes alcance sobre esa marca` | El jefe intenta asignar una marca de otro origen | Correcto: lo hace admin, gerencia o el jefe del origen |
| `La marca no está clasificada` | Se intenta asignar antes de clasificar | Marcas → botón nacional / internacional |
